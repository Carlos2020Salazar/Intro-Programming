//Carlos Salazar
using namespace std;
#include <iostream>

float similarityScore(string sequenceOne,string sequenceTwo)
{
    float similarity;
    float hammingDistance = 0;

    if (sequenceOne.length() == sequenceTwo.length())
    {
        int i = 0;
        while (i < sequenceOne.length())
        {
            if (sequenceOne[i] != sequenceTwo[i])
            {
                hammingDistance++;
            }
        i++;
        }
        similarity = ((sequenceOne.length()-hammingDistance)/sequenceOne.length());
    }
    else if(sequenceOne.length() != sequenceTwo.length())
        {
            return 0;
        }
    return similarity;
}
int countMatches(string genome,string sequenceThree,float minScore)
{
    float similarity;
    string myString;
    int count1 = 0;
    int i = 0;
    while (i < genome.length())
    {
        myString = genome.substr(i,sequenceThree.length());
        similarity = similarityScore(myString,sequenceThree);
        if(similarity >= minScore)
        {
            count1++;
        }
        i++;
    }
    return count1;
}
float findBestMatch(string genomeTwo,string seq)
{
    float value;
    float newValue = 0;
    string myString;
    for(int i = 0; i < genomeTwo.length(); i++)
    {
        myString = genomeTwo.substr(i ,seq.length());
        value = similarityScore(myString,seq);
        if ( value > newValue)
        {
            newValue = value;
        }
    }
    return newValue;
}
int findBestGenome(string humanDNA,string mouseDNA,string unknownDNA,string seq1)
{
    float match1 = findBestMatch(humanDNA,seq1);
    float match2 = findBestMatch(mouseDNA,seq1);
    float match3 = findBestMatch(unknownDNA,seq1);

    if((match1 > match2)&&(match1 > match3))
        return 1;
    else if((match2 > match1)&&(match2 > match3))
        return 2;
    else if((match3 > match1)&&(match3 > match2))
        return 3;
    else if((match1 == match2)||(match1 == match3)||(match2 == match3))
        return 0;
}
