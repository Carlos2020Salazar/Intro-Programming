//Carlos Salazar
//Vipra Gupta Rec 103
//Assignment 5
using namespace std;
#include <iostream>

float sumArray(float myArray[], int length)
{
    //Finding each value in array and adding

    int i;
    float sum = 0.00;
    //Will index through array
    for(i=0; i < length; i++)
    {

        //Find the total sum
        if(myArray[i] >= 0)
            sum = sum + myArray[i];
    }

    return sum;
}

//Find the target within the array and count where it is
int search(int array_[],int size_, int target)
{
    int count = 0;
    //Go through the array
    for(int i = size_ ; i > 0; i--)
    {
        //Find the index of the target
        if(array_[i] == target)
            count = i;
    }
    //If never found return -1
    if( count == 0)
        count = -1;
    return count;
}
//Find the sum of the squared differences of array
//Square the differences by multiplying twice
float calculateDifference(int a[],int b[], int size2_)
{
    int sumA=0;
    int sumB=0;
    float Diff_;
    //Each position there is a difference
    for(int i = 0; i < size2_; i++)
    {
        sumA= (a[i] - b[i])*(a[i] - b[i]);
        sumB = sumB + sumA;
    }
    //Will find the total sum of differences
    Diff_ = sumB;
    return Diff_;
}
//Bubble sort the array
// Put from lowest to highest
void sortArray(float unsortedArray[],int size3_)
{
    //Will go through each position and compare two values
    for(int i = size3_-1; i > 0; i--)
    {
        for(int j = 0; j < i; j++)
        {
            //Last position is always one less than size
            if(unsortedArray[j] > unsortedArray[j+1])
            {
                int number = unsortedArray[j+1];
                unsortedArray[j+1] = unsortedArray[j];
                unsortedArray[j] = number;
            }
        }
    }
}
//Store each value of array into a different array
void copyArray(float source[],int size4_,float dest[])
{
    float Num;
    //Each value in each position will be stored
    for(int i = 0; i < size4_; i++)
    {
        dest[i] = source[i];
    }
}
//Have each value store a string that corresponds with the value
//Store the string into an array with that type
void convert(int rating[],string text[],int size5_)
{
    string myString = "";
    //Go through each position and compare the value
    //If it matches store the corresponding string
    for(int i=0; i < size5_; i++)
    {
        if(rating[i] == 0)
        {
            myString = "Not-read";
            text[i] = myString;
        }
        else if(rating[i] == -5)
        {
            myString = "Terrible";
            text[i] = myString;
        }
        else if(rating[i] == -3)
        {
            myString = "Disliked";
            text[i] = myString;
        }
        else if(rating[i] == 1)
        {
           myString = "Average";
           text[i] = myString;
        }
        else if(rating[i] == 3)
        {
            myString = "Good";
            text[i] = myString;
        }
        else if(rating[i] == 5)
        {
           myString = "Excellent";
           text[i] = myString;
        }
        else
        {
            myString = "INVALID";
           text[i] = myString;
        }

    }
}
//Store into a new array
//Bubble sort the new array
//Find the median
float findMedian(float array[],int size6_)
{
    float sum;
    int pos;
    // copy array then order from smallest to
    // first copycode
    // bubblesort
    float array2_[size6_];

    //Storing each value in a new array
    for(int i = 0; i < size6_; i++)
    {
        array2_[i] = array[i];
    }
    //Bubblesorting the array;
    for(int j = size6_-1; j > 0; j--)
    {
        for(int k = 0; k < j; k++)
        {
            if(array2_[k] > array2_[k+1])
            {
                int number = array2_[k+1];
                array2_[k+1] = array2_[k];
                array2_[k] = number;
            }
        }
    }
    //Finding the median
    if(size6_%2 == 0)
    {
        pos = (size6_/2);
        sum = ((array2_[pos] + array2_[(pos-1)])/2);
    }
    if(size6_%2 > 0)
    {
        pos = ((size6_-1)/2);

        sum = array2_[pos];
    }
    return sum;
}
