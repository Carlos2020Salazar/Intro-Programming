//Carlos Salazar
using namespace std;
#include <iostream>
#include "Assignment5.cpp"
int main()
{
    int length;
    cin >> length;
    float myArray[length];
    for (int i = 0; i < length; i++)
        cin >> myArray[i];
    cout << sumArray(myArray,length)<<endl;
    //Prob B
    int size_;
    cin >> size_;
    int target;
    cin >> target;
    int array_[size_];
    for (int i = 0; i < size_ ; i++)
        cin >>array_[i];
    cout << search(array_,size_,target)<<endl;
    //Prob C
    int size2_;
    cin >> size2_;
    int a[size2_];
    for (int i = 0; i < size2_ ; i++)
        cin >>a[i];
    int b[size2_];
    for (int i = 0; i < size2_ ; i++)
        cin >>b[i];
    cout << calculateDifference(a,b,size2_)<<endl;
    //Prob D
    int size3_;
    cin >> size3_;
    float unsortedArray[size3_];
    for(int i = 0; i < size3_; i++)
        cin >> unsortedArray[i];
    sortArray(unsortedArray,size3_);
    //Prob E
    int size4_;
    cin >> size4_;
    float source[size4_];
    float dest[size4_];
    for(int i=0; i< size4_;i++)
        cin >> source[i];
    copyArray(source,size4_,dest);
    //Prob F
    int size5_;
    cin >> size5_;
    int rating[size5_];
    for (int i =0; i < size5_;i++)
    {
        cin >> rating[i];
    }
    string text[size5_];
    convert(rating,text,size5_);
    //Prob G
    int size6_;
    cin >> size6_;
    float array[size6_];
    for (int i =0; i < size6_;i++)
    {
        cin >> array[i];
    }
    findMedian(array,size6_);
}
