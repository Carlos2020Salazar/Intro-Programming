//Carlos Salazar
//Vipra Gupta 103
//Assignment 7
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string.h>
#include <sstream>
#include "SpellChecker.h"
using namespace std;

//Will initialize the private variables
SpellChecker::SpellChecker()
{
    string Lang = "";

    char start_marker = '\0';
    char end_marker = '\0';
    //Will fill array with the null
    for(int i=0; i < 10000; i++)
    {
        ValidWords[i]="";
    }
}
//Will set the language
SpellChecker::SpellChecker(string Lang)
{
    language = Lang;
}
//Will store files and language
SpellChecker::SpellChecker(string Lang,string f1,string f2) //1:correct 2:Incorrect
{
    language = Lang;
    filename1 = f1;
    filename2 = f2;
}
//Deconstructor method
SpellChecker::~SpellChecker(){}

//Will be the getter for a count
int SpellChecker::getcounter()
{

    return count;
}
//Initialize a count
//The setter method for the count
void SpellChecker::setcounter(int value)
{

    count = value;
}
//Method will read through the file and manipulate
bool SpellChecker::readValidWords(string filename)
{

   //Open File and return boolean
   ifstream file(filename);
    string str;
    int count=0;
    int i=0;
    bool A=false;
    if(file.is_open()){
        while (std::getline(file, str)) //While it reaches in end of file
        {
            A=true;
        ValidWords[i]=str;
        i++;
        }
    A = true;
    }
    else
        return A;
}
//Method to read the correct words
bool SpellChecker::readCorrectedWords(string filename)
{
//Begin to read in the file
ifstream file(filename);
    string str;
    int count=0;
    bool A=false;
    int j=0;
    //While it is able to store a line
    if(file.is_open())
    {
        while (std::getline(file, str))
        {
            size_t pos = str.find('\t'); // locate delimiter
        }
        return true;
    }
    else
        return A;
}
//
string SpellChecker::repair(string string)
{
    ifstream file;
    file.open("MISSPELLED.txt");
    string str;
    int count=0;
   // int i=getcounter();
    //bool flag=false;
    int j=0;
    while (std::getline(file, str))
    {



       //std::stringstream   linestream(str);
    string  data;
    string data1;
    string data2;

    size_t pos = str.find('\t'); // locate delimiter

    if (string::npos == pos) {

    //std::cout<<"error";
    // no delimiter, handle error
  }
  else
  {

    data1 = str.substr(0,pos - 1);
    data2 = str.substr(pos, str.length() - pos);
  }
    string x=data1;
    string y=data2;
    if(x == y)
    {
        std::cout<<data2;
    }
   }
}



