#include <iostream>
#include "WordsCount.h"
#include "SpellChecker.h"
using namespace std;

int main()
{


}

