#ifndef WordCounts_H
#define WordCounts_H
#include <iostream>
#include "WordsCount.h"
#include "SpellChecker.h"
using namespace std;

class WordCounts
{




};
#endif

