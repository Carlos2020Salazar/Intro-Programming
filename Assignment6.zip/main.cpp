//Carlos Salazar
//Vipra Gupta 103
//Assignment 7
//2nd Yr. Jahtin G.
#include<iostream>
#include "SpellChecker.h"
#include "SpellChecker.cpp"
using namespace std;

int main()
{
   //Creating the first three objects A,B,C
   SpellChecker A;
   SpellChecker B("test");
   SpellChecker C("t1","t2","t3");
   Passing Object A to call methods
   A.readValidWords("VALID_WORDS_3000.txt");
   A.readCorrectedWords("MISSPELLED.txt");
   A.repair("equir");
    return 0;

}
