//Carlos Salazar
//Vipra Gupta -103
//Project Proposal


class BlackJackGame
{
    public:
    class BlackJackGame();

    set_Bet();
    get_Bet();
    //Setter_Getter for the bet placed by user
    set_move();
    get_move();
    //Setter/Getter for the move by the user
    get_players();
    set_players();
    //Setter/Getter for the standing of other players

    IF STATEMENT
    When the player has a larger value than dealer, User Wins
    When player is largest within the table, Player wins full pot;
    While Statement/For Statements
     while cards are dealt, then game continues
    for each player deal a card
        player still has a pot, then the game continues
        player does not remove bet, hand is dealt
    File IO
        The outcomes(odds) of the dealer depending on the hand;



    private:

    int Number[11]; //Will be the value of the card 1-10

    char Suit[16]; // Will be the suit of the card, each suit has 16 cards

    string move_; // Will be the moves allowed by the user defined by rules of game

    int Bet; // Will be the amount to place the bet

    string players; //Will represent the other players standing within the game to see who wins the pot





};
