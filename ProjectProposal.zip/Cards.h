//Carlos Salazar
//Vipra Gupta -103
//Project Proposal


class Cards
{
public:
    Cards();
    //Initialize the card
    get_symbol();
    set_symbol();
    //Setter/Getter for the card selected
    get_value();
    set_value();
    //Setter/Getter for the card dealt
    if statements
    if value/symbol is greater than dealer, they wint;
    else the dealer wins;

    while/For statements
    while cards are dealt, then game continues
    for each player deal a card
    File IO
    Read Each card in the deck


private:
    char symbol[11]; //suit of the card possible
    int value[11]; //value of the card possible









};
